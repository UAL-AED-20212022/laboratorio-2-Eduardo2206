from models.LinkedList import LinkedList


def main ():

    lista_ligada = LinkedList()

    while True :

        try:

            valores = input().split(" ")

        except EOFError:
            return

        match valores[0]:
            
            case "RPI":
                lista_ligada.insert_at_start(valores[1])
                lista_ligada.traverse_list()

            case "RPF":
                lista_ligada.insert_at_end(valores[1])
                lista_ligada.traverse_list()
            
            case "RPDE":
                lista_ligada.insert_after_item(valores[2],valores[1])
                lista_ligada.traverse_list()
            
            case "RPAE":
                lista_ligada.insert_before_item(valores[2],valores[1])
                lista_ligada.traverse_list()
            
            case "RPII":
                lista_ligada.insert_at_index(int(valores[2]),valores[1])
                lista_ligada.traverse_list()

            case "VNE":
                print(f"O numero de elementos são {lista_ligada.get_count()}.")

            case "VP":
                if lista_ligada.search_item(valores[1]):
                    print(f"O país  { valores[1]} encontra-se na fila.")

                else:
                    print(f"O país {valores[1]} não se encontra na fila.")

            case "EPE":
                print(f"O país {lista_ligada.start_node.get_item()} foi eliminado da lista.")
                lista_ligada.delete_at_start()

            case "EUE":
                print(f"O país {lista_ligada.get_last_node()} foi eliminado da lista.")
                lista_ligada.delete_at_end()

            case "EP":
                if lista_ligada.delete_element_by_value(valores[1]):
                    print(f"O país {valores[1]} não se encontra na fila.")
                
                else:
                    print(f"O país {valores[1]} foi eliminado com sucesso.")